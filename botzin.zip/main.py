import discord
from discord.ext import commands

# Token embutida diretamente no código (NÃO RECOMENDADO PUBLICAMENTE)
TOKEN = "MTExNjQxMjgzMjU2OTg4NDcyNQ.GeXzxE.iaaCtTNJR_aygIYnuMpsCW-gUYXGjxps1oEc84"

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())

@bot.event
async def on_ready():
    print(f"✅ Bot online como {bot.user}")

@bot.command()
async def ping(ctx):
    await ctx.send("🏓 Pong!")

bot.run(TOKEN)
